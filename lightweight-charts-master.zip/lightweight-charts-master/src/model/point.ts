import { Coordinate } from './coordinate';

export interface Point {
	readonly x: Coordinate;
	readonly y: Coordinate;
}
