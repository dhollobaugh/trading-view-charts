import { Nominal } from '../helpers/nominal';

export type Coordinate = Nominal<number, 'Coordinate'>;
